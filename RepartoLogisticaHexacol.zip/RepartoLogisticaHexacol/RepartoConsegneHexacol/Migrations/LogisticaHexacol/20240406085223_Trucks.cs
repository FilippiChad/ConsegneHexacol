﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RepartoConsegneHexacol.Migrations.LogisticaHexacol
{
    /// <inheritdoc />
    public partial class Trucks : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Truck",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Targa = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SocietaProvenienza = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    CapienzaCisterna = table.Column<int>(type: "int", nullable: false),
                    TipoAlcol = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Entrato = table.Column<bool>(type: "bit", nullable: false),
                    Riempito = table.Column<bool>(type: "bit", nullable: false),
                    PrioritaMax = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Truck", x => x.Id);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Truck");
        }
    }
}
