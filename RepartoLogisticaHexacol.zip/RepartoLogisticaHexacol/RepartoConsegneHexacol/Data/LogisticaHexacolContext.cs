﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using RepartoConsegneHexacol.Models;

namespace RepartoConsegneHexacol.Data
{
    public class LogisticaHexacolContext : DbContext
    {
        public LogisticaHexacolContext (DbContextOptions<LogisticaHexacolContext> options)
            : base(options)
        {
        }

        public DbSet<RepartoConsegneHexacol.Models.Truck> Truck { get; set; } = default!;
    }
}
