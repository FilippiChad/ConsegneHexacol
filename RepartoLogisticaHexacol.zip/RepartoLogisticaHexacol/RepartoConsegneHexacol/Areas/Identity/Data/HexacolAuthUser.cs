﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace RepartoConsegneHexacol.Areas.Identity.Data;

// Add profile data for application users by adding properties to the HexacolAuthUser class
public class HexacolAuthUser : IdentityUser
{
    [PersonalData]
    public string UserType { get; set; } //Ruolo

    [PersonalData]
    [RegularExpression(@"^[A-Z]{2}\d{2}[A-Z]{2}$", ErrorMessage = "Il Codice Lavoratore non è valido.")]
    public string CodiceLavoratore { get; set; }
}

