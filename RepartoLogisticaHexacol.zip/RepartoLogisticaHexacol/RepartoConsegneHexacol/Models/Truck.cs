﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace RepartoConsegneHexacol.Models
{
    public class Truck
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required(ErrorMessage = "Il campo Targa è obbligatorio.")]
        [RegularExpression(@"^[a-zA-Z]{2}\d{3}[a-zA-Z]{2}$", ErrorMessage = "Il Codice Lavoratore non è valido.")]
        public string Targa { get; set; }

        [Required(ErrorMessage = "Il campo Societá di provenienza è obbligatorio.")]
        public string SocietaProvenienza { get; set; }

        [Required(ErrorMessage = "Il campo Capienza è obbligatorio.")]
        public int CapienzaCisterna { get; set; }
        public string TipoAlcol { get; set; }

        [DefaultValue(false)]
        public bool Entrato { get; set; }

        [DefaultValue(false)]
        public bool Riempito { get; set; }
        [DefaultValue(false)]
        public bool PrioritaMax { get; set; }

        [Required(ErrorMessage = "Il campo Data Arrivo è obbligatorio.")]
        [DataType(DataType.Date)]
        public DateTime Data_Arrivo { get; set; }

        [Required(ErrorMessage = "Il campo Ora Arrivo è obbligatorio.")]
        public TimeSpan Ora_Arrivo { get; set; }

        public string Data_Arrivo_Formattata
        {
            get { return Data_Arrivo.ToShortDateString(); }
        }

        public string Ora_Arrivo_Formattata
        {
            get { return Ora_Arrivo.ToString(@"hh\:mm"); }
        }
    }
}
