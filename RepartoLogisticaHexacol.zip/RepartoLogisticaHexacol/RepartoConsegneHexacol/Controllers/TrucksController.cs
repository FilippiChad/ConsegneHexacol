﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RepartoConsegneHexacol.Data;
using RepartoConsegneHexacol.Models;

namespace RepartoConsegneHexacol.Controllers
{
    public class TrucksController : Controller
    {
        private readonly LogisticaHexacolContext _context;

        public TrucksController(LogisticaHexacolContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Gestore")]
        public async Task<IActionResult> Consegne()
        {
            var trucks = await _context.Truck.Where(t => t.Riempito.Equals(false)).OrderByDescending(t => t.PrioritaMax).ThenBy(t => t.Id).ToListAsync();
            int count = 0;

            foreach (var truck in trucks)
            {
                if (count < 4)
                {
                    truck.Entrato = true;
                    _context.Update(truck);
                    await _context.SaveChangesAsync();

                    // Simula l'attesa di 30 secondi per riempire la cisterna
                    await Task.Delay(10000);

                    truck.Riempito = true;
                    _context.Update(truck);
                    await _context.SaveChangesAsync();

                    count++;
                }
                else
                {
                    break;
                }
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Trucks
        [Authorize(Roles = "Gestore,Schedatore")]
        public async Task<IActionResult> Index()
        {
              return _context.Truck != null ? 
                          View(await _context.Truck.ToListAsync()) :
                          Problem("Entity set 'LogisticaHexacolContext.Truck'  is null.");
        }

        // GET: Trucks/Details/5
        [Authorize(Roles = "Gestore,Schedatore")]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Truck == null)
            {
                return NotFound();
            }

            var truck = await _context.Truck
                .FirstOrDefaultAsync(m => m.Id == id);
            if (truck == null)
            {
                return NotFound();
            }

            return View(truck);
        }

        // GET: Trucks/Create
        [Authorize(Roles = "Schedatore")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Trucks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Schedatore")]
        public async Task<IActionResult> Create([Bind("Id,Targa,SocietaProvenienza,CapienzaCisterna,TipoAlcol,Entrato,Riempito,PrioritaMax,Data_Arrivo,Ora_Arrivo")] Truck truck)
        {
            if (ModelState.IsValid)
            {
                _context.Add(truck);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(truck);
        }

        // GET: Trucks/Edit/5
        [Authorize(Roles = "Gestore")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Truck == null)
            {
                return NotFound();
            }

            var truck = await _context.Truck.FindAsync(id);
            if (truck == null)
            {
                return NotFound();
            }
            return View(truck);
        }

        // POST: Trucks/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Gestore")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Targa,SocietaProvenienza,CapienzaCisterna,TipoAlcol,Entrato,Riempito,PrioritaMax,Data_Arrivo,Ora_Arrivo")] Truck truck)
        {
            if (id != truck.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(truck);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TruckExists(truck.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(truck);
        }

        // GET: Trucks/Delete/5
        [Authorize(Roles = "Gestore,Schedatore")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Truck == null)
            {
                return NotFound();
            }

            var truck = await _context.Truck
                .FirstOrDefaultAsync(m => m.Id == id);
            if (truck == null)
            {
                return NotFound();
            }

            return View(truck);
        }

        // POST: Trucks/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Truck == null)
            {
                return Problem("Entity set 'LogisticaHexacolContext.Truck'  is null.");
            }
            var truck = await _context.Truck.FindAsync(id);
            if (truck != null)
            {
                _context.Truck.Remove(truck);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool TruckExists(int id)
        {
          return (_context.Truck?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }


}
